﻿
using UnityEngine;
using UnityEngine.SceneManagement; 

public class PlayAgain : MonoBehaviour {


	public void LoadBeginning () 
	{


		SceneManager.LoadScene (0); 

	}







}
