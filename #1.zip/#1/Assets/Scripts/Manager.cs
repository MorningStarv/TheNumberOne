﻿using UnityEngine;
using UnityEngine.SceneManagement; 


public class Manager : MonoBehaviour {

	public GameObject CompleteLevelUI; 

	public void CompleteLevel () 
	{
	
		CompleteLevelUI.SetActive (true); 
	
	}



}
