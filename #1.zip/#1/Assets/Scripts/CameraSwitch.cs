﻿
using UnityEngine;

public class CameraSwitch : MonoBehaviour {

	public Camera mainCam; 

	public Camera camOne; 

	public Camera camTwo; 

	public Camera camThree; 

	private void Awake () 
	{
		mainCam.enabled = true; 
		camOne.enabled = false; 
		camTwo.enabled = false; 
		camThree.enabled = false; 


	}

	public void SwitchCam  () 
	{
		mainCam.enabled = !mainCam.enabled; 
		camOne.enabled = !camOne.enabled; 
		camTwo.enabled = !camTwo.enabled; 
		camThree.enabled = !camThree.enabled; 



	}



	
	// Update is called once per frame
	void FixedUpdate () 
	{

		if (Input.GetKey ("p")) 
		{
			mainCam.enabled = true;
			camOne.enabled = false;
			camTwo.enabled = false;
			camThree.enabled = false;
		}
	
		if (Input.GetKey ("1")) 
		{
			mainCam.enabled = false;
			camOne.enabled = true; 
			camTwo.enabled = false; 
			camThree.enabled = false;
		}

		if (Input.GetKey ("2"))
		{
			mainCam.enabled = false;
			camOne.enabled = false; 
			camTwo.enabled = true; 
			camThree.enabled = false;
		}

		if (Input.GetKey ("3")) 
		{
			mainCam.enabled = false; 
			camOne.enabled = false;
			camTwo.enabled = false;
			camThree.enabled = true;
		}
		
}

}
