﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class fall : MonoBehaviour {

	public Rigidbody fallCube;
	public GameObject destroyCube; 




	void OnCollisionEnter () 
	{







			fallCube.useGravity = true; 
		Destroy (destroyCube); 



		



	}





	// Use this for initialization
	void Start () {

		fallCube.useGravity = false; 




		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
