﻿
using UnityEngine;

public class OnOff : MonoBehaviour {

	public GameObject canvasControl; 

	private bool toggle = false; 




	public void CanvasOnOff () 
	{
		if (!toggle) {
		
			canvasControl.SetActive (true); 
			toggle = true; 
		
		} 
		else 
		{
			canvasControl.SetActive (false); 
			toggle = false; 
		
		}
	
	}







}
