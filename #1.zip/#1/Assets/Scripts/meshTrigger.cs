﻿using UnityEngine;

public class meshTrigger : MonoBehaviour {


	public MeshRenderer Mesh; 



	// Use this for initialization
	void Start () 
	{
		
		Mesh.enabled = false; 

	}


	void OnCollisionEnter () 
	{



			Mesh.enabled = true; 

	


	}




}
