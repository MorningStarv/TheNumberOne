﻿using UnityEngine;

public class Release : MonoBehaviour {
			


	public Rigidbody fallCube; 
	public float up = 100f; 


	void OnCollisionEnter () 
	{

		fallCube.useGravity = false; 
		fallCube.AddForce (0, up * Time.deltaTime , 0); 
		
	
	}







	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
