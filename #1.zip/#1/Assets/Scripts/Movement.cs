﻿using UnityEngine;

public class Movement : MonoBehaviour {

	public Rigidbody rb; 

	public float UpDown = 10f; 

	public float LeftRight = 10f; 

	
	// Update is called once per frame
	void FixedUpdate () 
	{


		if (Input.GetKey ("d")) 
		{
			rb.AddForce (LeftRight * Time.deltaTime, 0, 0, ForceMode.VelocityChange); 
		}

		if (Input.GetKey ("a")) 
		{
			rb.AddForce (-LeftRight * Time.deltaTime, 0, 0, ForceMode.VelocityChange); 
		}

		if (Input.GetKey ("s")) 
		{
			rb.AddForce (0, 0, -UpDown * Time.deltaTime, ForceMode.VelocityChange); 
		}

		if (Input.GetKey ("w")) 
		{
			rb.AddForce (0, 0, UpDown * Time.deltaTime, ForceMode.VelocityChange); 
		}
		
	}
}
