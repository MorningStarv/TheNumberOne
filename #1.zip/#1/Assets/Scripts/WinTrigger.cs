﻿
using UnityEngine;

public class WinTrigger : MonoBehaviour {

	public Manager gameManager; 

	void OnTriggerEnter ()
	{

		gameManager.CompleteLevel (); 

	} 


}
