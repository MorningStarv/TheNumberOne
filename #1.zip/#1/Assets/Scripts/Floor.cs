﻿
using UnityEngine;

public class Floor : MonoBehaviour {

	public Rigidbody floor;
	public float down = -100f; 




	void OnCollisionEnter () 
	{
		
			floor.useGravity = false;
			floor.isKinematic = false; 
			floor.AddForce (0, down * Time.deltaTime , 0); 

		
		
	
	
	
	
	}








	// Use this for initialization
	void Start () {


		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
