﻿
using UnityEngine;

public class Destroy : MonoBehaviour {

	public GameObject Titself; 
	public GameObject cubbe; 
	public GameObject cubbe1;
	public GameObject cubbe2;
	public GameObject cubbe3; 
	public GameObject cubbe4; 
	public GameObject cubbe5; 

	void OnCollisionEnter () 

	{
	
		
		Destroy (cubbe); 
		Destroy (cubbe1); 
		Destroy (cubbe2); 
		Destroy (cubbe3);	
		Destroy (cubbe4);
		Destroy (cubbe5); 
		Destroy (Titself); 
	
	}





	// Use this for initialization
	void Start () {




	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
